<?php
/** 
*@package Usedcarsplugin
*/

/*

* Plugin Name : Usedcars Plugin
* PLugin URI : https://github.com/14Deveshjoshi/plugin/
* Description: This plugin adds a form for get data from database.
 * Version:     1.0
 * Author:      Devesh Joshi
 * Author URI:  http://www.deveshjoshi.info
*/
